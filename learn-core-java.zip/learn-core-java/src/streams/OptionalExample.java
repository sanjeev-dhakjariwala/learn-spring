package streams;

import java.util.Optional;

// Demonstrates Optional usage
public class OptionalExample {
    public static void main(String[] args) {
        Optional<String> opt = Optional.ofNullable(null);
        System.out.println(opt.orElse("Default"));
        opt = Optional.of("Java");
        opt.ifPresent(System.out::println);
    }
}

