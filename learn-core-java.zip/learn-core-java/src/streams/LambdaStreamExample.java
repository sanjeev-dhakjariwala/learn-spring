package streams;

import java.util.*;
import java.util.stream.*;

// Demonstrates lambda, functional interface, method reference, streams
public class LambdaStreamExample {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("a", "bb", "ccc", "dd");
        list.stream().filter(s -> s.length() > 1)
            .map(String::toUpperCase)
            .forEach(System.out::println);
        int sum = list.stream().mapToInt(String::length).sum();
        System.out.println("Sum of lengths: " + sum);
    }
}

