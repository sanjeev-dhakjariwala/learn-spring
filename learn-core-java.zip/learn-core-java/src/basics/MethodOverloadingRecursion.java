package basics;

// Demonstrates method overloading and recursion
public class MethodOverloadingRecursion {
    public int add(int a, int b) { return a + b; }
    public double add(double a, double b) { return a + b; }

    public int factorial(int n) {
        if (n <= 1) return 1;
        return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        MethodOverloadingRecursion ex = new MethodOverloadingRecursion();
        System.out.println("add(int, int): " + ex.add(2, 3));
        System.out.println("add(double, double): " + ex.add(2.5, 3.5));
        System.out.println("factorial(5): " + ex.factorial(5));
    }
}

