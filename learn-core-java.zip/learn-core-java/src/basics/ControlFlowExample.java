package basics;

// Demonstrates Java control flow: if, switch, loops
public class ControlFlowExample {
    public static void main(String[] args) {
        int x = 5;
        if (x > 0) {
            System.out.println("x is positive");
        } else {
            System.out.println("x is not positive");
        }

        switch (x) {
            case 1 -> System.out.println("One");
            case 5 -> System.out.println("Five");
            default -> System.out.println("Other");
        }

        for (int i = 0; i < 3; i++) {
            System.out.println("i = " + i);
        }
    }
}
