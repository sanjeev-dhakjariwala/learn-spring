package generics;

// Demonstrates generic class, method, wildcards, bounded types
class Box<T> {
    private T value;
    public Box(T value) { this.value = value; }
    public T get() { return value; }
}

public class GenericsExample {
    public static <T> void printBox(Box<? extends T> box) {
        System.out.println("Box contains: " + box.get());
    }
    public static void main(String[] args) {
        Box<Integer> intBox = new Box<>(123);
        Box<String> strBox = new Box<>("Hello");
        printBox(intBox);
        printBox(strBox);
    }
}

