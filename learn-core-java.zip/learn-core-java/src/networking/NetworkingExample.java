package networking;

import java.net.*;
import java.io.*;

// Demonstrates basic URL connection
public class NetworkingExample {
    public static void main(String[] args) throws Exception {
        URL url = new URL("https://www.example.com");
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {
            System.out.println("First line: " + in.readLine());
        }
    }
}

