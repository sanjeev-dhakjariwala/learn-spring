package oop;

// Abstraction: Hiding complex implementation details and showing only the necessary features.
// Achieved using abstract classes or interfaces.
abstract class Vehicle {
    public abstract void start();
}

public class AbstractionExample extends Vehicle {
    @Override
    public void start() {
        System.out.println("Car starts");
    }
}
