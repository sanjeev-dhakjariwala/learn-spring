package oop;

// Polymorphism: Ability of an object to take many forms.
// Method overriding demonstrates runtime polymorphism.
class AnimalPoly {
    void sound() {
        System.out.println("Animal makes a sound");
    }
}

class DogPoly extends AnimalPoly {
    @Override
    void sound() {
        System.out.println("Dog barks");
    }
}

public class PolymorphismExample {
    public static void main(String[] args) {
        AnimalPoly a = new DogPoly(); // Upcasting
        a.sound(); // Calls DogPoly's sound()
    }
}

