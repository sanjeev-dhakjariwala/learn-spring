package oop;

// Inheritance: Mechanism where one class acquires properties and behaviors of another class.
// Dog inherits from Animal.
class Animal {
    public void eat() {
        System.out.println("Animal eats");
    }
}

// Only one public class per file is allowed in Java. Make InheritanceExample package-private.
public class InheritanceExample extends Animal {
    public void bark() {
        System.out.println("Dog barks");
    }
}
