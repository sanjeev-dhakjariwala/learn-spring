package patterns;

// Demonstrates Singleton pattern
public class SingletonPattern {
    private static final SingletonPattern INSTANCE = new SingletonPattern();
    private SingletonPattern() {}
    public static SingletonPattern getInstance() { return INSTANCE; }
    public void show() { System.out.println("Singleton instance"); }
    public static void main(String[] args) {
        SingletonPattern.getInstance().show();
    }
}

