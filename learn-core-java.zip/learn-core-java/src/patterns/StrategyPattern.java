package patterns;

// Demonstrates Strategy pattern
interface Strategy { int execute(int a, int b); }
class AddStrategy implements Strategy {
    public int execute(int a, int b) { return a + b; }
}
class Context {
    private Strategy strategy;
    public Context(Strategy strategy) { this.strategy = strategy; }
    public int execute(int a, int b) { return strategy.execute(a, b); }
}
public class StrategyPattern {
    public static void main(String[] args) {
        Context context = new Context(new AddStrategy());
        System.out.println("Result: " + context.execute(2, 3));
    }
}

