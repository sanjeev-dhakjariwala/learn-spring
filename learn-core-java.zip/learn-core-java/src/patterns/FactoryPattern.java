package patterns;

// Demonstrates Factory pattern
interface Product { void use(); }
class ConcreteProduct implements Product {
    public void use() { System.out.println("Using product"); }
}
class ProductFactory {
    public static Product createProduct() { return new ConcreteProduct(); }
}
public class FactoryPattern {
    public static void main(String[] args) {
        Product p = ProductFactory.createProduct();
        p.use();
    }
}

