package patterns;

import java.util.*;

// Demonstrates Observer pattern
interface Observer { void update(String msg); }
class Subject {
    private final List<Observer> observers = new ArrayList<>();
    public void addObserver(Observer o) { observers.add(o); }
    public void notifyObservers(String msg) {
        for (Observer o : observers) o.update(msg);
    }
}
public class ObserverPattern {
    public static void main(String[] args) {
        Subject subject = new Subject();
        subject.addObserver(msg -> System.out.println("Received: " + msg));
        subject.notifyObservers("Hello Observers!");
    }
}

