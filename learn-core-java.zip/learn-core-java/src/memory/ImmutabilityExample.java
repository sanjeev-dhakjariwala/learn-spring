package memory;

// Demonstrates creating immutable class
public final class ImmutabilityExample {
    private final int value;
    public ImmutabilityExample(int value) { this.value = value; }
    public int getValue() { return value; }
    public static void main(String[] args) {
        ImmutabilityExample obj = new ImmutabilityExample(10);
        System.out.println("Value: " + obj.getValue());
    }
}

