package memory;

// Demonstrates stack vs heap, GC basics
public class MemoryModelExample {
    public static void main(String[] args) {
        int x = 10; // stack
        String s = new String("heap"); // heap
        System.gc();
        System.out.println("Requested GC");
    }
}

