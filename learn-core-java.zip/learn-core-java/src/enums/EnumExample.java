package enums;

// Demonstrates enum basics, fields, methods, switch
enum Day {
    MONDAY, TUESDAY, WEDNESDAY;
    public boolean isWeekend() { return this == MONDAY; }
}
public class EnumExample {
    public static void main(String[] args) {
        Day d = Day.MONDAY;
        switch (d) {
            case MONDAY -> System.out.println("It's Monday");
            default -> System.out.println("Other day");
        }
        System.out.println("Is weekend? " + d.isWeekend());
    }
}

