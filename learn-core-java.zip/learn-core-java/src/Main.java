import oop.EncapsulationExample;
import oop.InheritanceExample;
import oop.AbstractionExample;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello and welcome!\n");

        // Encapsulation Example
        EncapsulationExample person = new EncapsulationExample();
        person.setName("Alice");
        person.setAge(30);
        System.out.println("Encapsulation: " + person.getName() + " is " + person.getAge() + " years old.");

        // Inheritance Example
        InheritanceExample dog = new InheritanceExample();
        dog.eat(); // inherited from Animal
        dog.bark(); // own method

        // Polymorphism Example
        oop.PolymorphismExample.main(null); // runs the polymorphism demo

        // Abstraction Example
        AbstractionExample car = new AbstractionExample();
        car.start();

        System.out.println();
        for (int i = 1; i <= 5; i++) {
            System.out.println("i = " + i);
        }
    }
}