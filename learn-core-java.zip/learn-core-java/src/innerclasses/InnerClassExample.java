package innerclasses;

// Demonstrates static, non-static, anonymous, local inner classes
public class InnerClassExample {
    static class StaticInner { void show() { System.out.println("Static inner"); } }
    class NonStaticInner { void show() { System.out.println("Non-static inner"); } }
    public void localInner() {
        class LocalInner { void show() { System.out.println("Local inner"); } }
        new LocalInner().show();
    }
    public void anonymousInner() {
        Runnable r = new Runnable() { public void run() { System.out.println("Anonymous inner"); } };
        r.run();
    }
    public static void main(String[] args) {
        new StaticInner().show();
        new InnerClassExample().new NonStaticInner().show();
        new InnerClassExample().localInner();
        new InnerClassExample().anonymousInner();
    }
}

