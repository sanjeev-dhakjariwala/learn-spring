package collections;

import java.util.*;

// Demonstrates iteration: Iterator, ListIterator, enhanced for-loop
public class IterationExample {
    public static void main(String[] args) {
        List<String> list = Arrays.asList("A", "B", "C");
        System.out.print("Iterator: ");
        Iterator<String> it = list.iterator();
        while (it.hasNext()) System.out.print(it.next() + " ");
        System.out.println();

        System.out.print("ListIterator (reverse): ");
        ListIterator<String> lit = list.listIterator(list.size());
        while (lit.hasPrevious()) System.out.print(lit.previous() + " ");
        System.out.println();

        System.out.print("Enhanced for-loop: ");
        for (String s : list) System.out.print(s + " ");
        System.out.println();
    }
}

