package collections;

import java.util.*;

// Demonstrates sorting and searching collections
public class SortingSearchingExample {
    public static void main(String[] args) {
        List<Integer> list = Arrays.asList(5, 2, 8, 1);
        Collections.sort(list);
        System.out.println("Sorted List: " + list);
        int idx = Collections.binarySearch(list, 8);
        System.out.println("Index of 8: " + idx);
    }
}

