package collections;

import java.util.*;

// Demonstrates immutable collections
public class ImmutableCollectionsExample {
    public static void main(String[] args) {
        List<String> immutableList = List.of("A", "B", "C");
        System.out.println("Immutable List: " + immutableList);
        // immutableList.add("D"); // Throws UnsupportedOperationException

        Set<String> immutableSet = Set.of("X", "Y");
        System.out.println("Immutable Set: " + immutableSet);

        Map<String, Integer> immutableMap = Map.of("A", 1, "B", 2);
        System.out.println("Immutable Map: " + immutableMap);
    }
}

