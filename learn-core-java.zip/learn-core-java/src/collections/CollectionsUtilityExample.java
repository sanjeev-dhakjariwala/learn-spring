package collections;

import java.util.*;

// Demonstrates Collections utility methods
public class CollectionsUtilityExample {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(Arrays.asList("A", "B", "C"));
        Collections.reverse(list);
        System.out.println("Reversed: " + list);
        Collections.shuffle(list);
        System.out.println("Shuffled: " + list);
        Collections.fill(list, "X");
        System.out.println("Filled: " + list);
    }
}

