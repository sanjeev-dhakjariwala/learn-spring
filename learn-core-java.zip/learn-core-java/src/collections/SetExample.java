package collections;

import java.util.*;

// Demonstrates Set usage: HashSet, LinkedHashSet, TreeSet
public class SetExample {
    public static void main(String[] args) {
        Set<String> hashSet = new HashSet<>(Arrays.asList("Banana", "Apple", "Cherry", "Apple"));
        System.out.println("HashSet (no duplicates, unordered): " + hashSet);

        Set<String> linkedHashSet = new LinkedHashSet<>(Arrays.asList("Banana", "Apple", "Cherry", "Apple"));
        System.out.println("LinkedHashSet (insertion order): " + linkedHashSet);

        Set<String> treeSet = new TreeSet<>(hashSet);
        System.out.println("TreeSet (sorted): " + treeSet);
    }
}

