package collections;

import java.util.*;

// Demonstrates Queue usage: PriorityQueue, ArrayDeque
public class QueueExample {
    public static void main(String[] args) {
        Queue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.offer(3);
        priorityQueue.offer(1);
        priorityQueue.offer(2);
        System.out.println("PriorityQueue (natural order): " + priorityQueue);
        System.out.println("Poll: " + priorityQueue.poll());

        Deque<String> arrayDeque = new ArrayDeque<>();
        arrayDeque.offer("A");
        arrayDeque.offerFirst("B");
        arrayDeque.offerLast("C");
        System.out.println("ArrayDeque: " + arrayDeque);
    }
}

