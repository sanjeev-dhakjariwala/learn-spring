package collections;

import java.util.*;

// Demonstrates Comparable and Comparator
class Fruit implements Comparable<Fruit> {
    String name;
    int price;
    Fruit(String name, int price) { this.name = name; this.price = price; }
    public int compareTo(Fruit o) { return this.price - o.price; }
    public String toString() { return name + "(" + price + ")"; }
}

public class ComparatorComparableExample {
    public static void main(String[] args) {
        List<Fruit> fruits = Arrays.asList(
            new Fruit("Apple", 30),
            new Fruit("Banana", 10),
            new Fruit("Cherry", 20)
        );
        Collections.sort(fruits); // Comparable
        System.out.println("Sorted by price (Comparable): " + fruits);
        fruits.sort(Comparator.comparing(f -> f.name)); // Comparator
        System.out.println("Sorted by name (Comparator): " + fruits);
    }
}

