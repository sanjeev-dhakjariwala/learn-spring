package collections;

import java.util.*;

// Demonstrates Stack (legacy) and Deque as stack
public class StackExample {
    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println("Legacy Stack: " + stack);
        System.out.println("Pop: " + stack.pop());

        Deque<Integer> dequeStack = new ArrayDeque<>();
        dequeStack.push(10);
        dequeStack.push(20);
        dequeStack.push(30);
        System.out.println("Deque as Stack: " + dequeStack);
        System.out.println("Pop: " + dequeStack.pop());
    }
}

