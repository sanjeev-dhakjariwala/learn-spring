package collections;

import java.util.*;
import java.util.concurrent.*;

// Demonstrates thread-safe collections
public class ThreadSafeCollectionsExample {
    public static void main(String[] args) {
        List<String> syncList = Collections.synchronizedList(new ArrayList<>());
        syncList.add("A");
        syncList.add("B");
        System.out.println("SynchronizedList: " + syncList);

        ConcurrentMap<String, Integer> cmap = new ConcurrentHashMap<>();
        cmap.put("X", 1);
        cmap.put("Y", 2);
        System.out.println("ConcurrentHashMap: " + cmap);
    }
}

