package collections;

import java.util.*;

// Demonstrates List usage: ArrayList and LinkedList
public class ListExample {
    public static void main(String[] args) {
        List<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Cherry");
        System.out.println("ArrayList: " + arrayList);

        LinkedList<String> linkedList = new LinkedList<>(arrayList);
        linkedList.addFirst("First");
        linkedList.addLast("Last");
        System.out.println("LinkedList: " + linkedList);
    }
}
