package thread;

// Demonstrates thread lifecycle and states
public class ThreadLifecycle {
    static class DemoThread extends Thread {
        public void run() {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        DemoThread t = new DemoThread();
        System.out.println("State after creation: " + t.getState());
        t.start();
        System.out.println("State after start: " + t.getState());
        Thread.sleep(50);
        System.out.println("State during run: " + t.getState());
        t.join();
        System.out.println("State after termination: " + t.getState());
    }
}

