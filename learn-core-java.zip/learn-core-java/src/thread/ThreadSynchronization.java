package thread;

// Demonstrates thread synchronization using synchronized methods and blocks
public class ThreadSynchronization {
    private int count = 0;

    // Synchronized method
    public synchronized void increment() {
        count++;
    }

    public void runDemo() throws InterruptedException {
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) increment();
        });
        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 1000; i++) increment();
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println("Final count (should be 2000): " + count);
    }

    public static void main(String[] args) throws InterruptedException {
        new ThreadSynchronization().runDemo();
    }
}

