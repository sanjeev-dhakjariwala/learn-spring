package thread;

// Demonstrates thread creation by extending Thread and implementing Runnable
public class ThreadCreation {
    // Extending Thread
    static class MyThread extends Thread {
        public void run() {
            System.out.println("Thread by extending Thread: " + Thread.currentThread().getName());
        }
    }

    // Implementing Runnable
    static class MyRunnable implements Runnable {
        public void run() {
            System.out.println("Thread by implementing Runnable: " + Thread.currentThread().getName());
        }
    }

    public static void main(String[] args) {
        MyThread t1 = new MyThread();
        t1.start();

        Thread t2 = new Thread(new MyRunnable());
        t2.start();
    }
}
