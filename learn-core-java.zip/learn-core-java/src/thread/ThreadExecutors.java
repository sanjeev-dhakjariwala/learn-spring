package thread;

import java.util.concurrent.*;

// Demonstrates ExecutorService, Callable, and Future
public class ThreadExecutors {
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newSingleThreadExecutor();
        Callable<String> task = () -> {
            Thread.sleep(100);
            return "Result from Callable";
        };
        Future<String> future = executor.submit(task);
        System.out.println("Future result: " + future.get());
        executor.shutdown();
    }
}

