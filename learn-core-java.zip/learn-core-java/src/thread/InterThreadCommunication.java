package thread;

// Demonstrates inter-thread communication using wait, notify, notifyAll
public class InterThreadCommunication {
    private static final Object lock = new Object();
    private static boolean ready = false;

    static class WaitingThread extends Thread {
        public void run() {
            synchronized (lock) {
                while (!ready) {
                    try {
                        lock.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.println("Thread notified and proceeding");
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        WaitingThread t = new WaitingThread();
        t.start();
        Thread.sleep(100);
        synchronized (lock) {
            ready = true;
            lock.notify();
        }
    }
}

