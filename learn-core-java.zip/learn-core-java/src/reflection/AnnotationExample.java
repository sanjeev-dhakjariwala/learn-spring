package reflection;

import java.lang.annotation.*;

// Demonstrates custom annotation and usage
@Retention(RetentionPolicy.RUNTIME)
@interface MyAnnotation { String value(); }

@MyAnnotation("TestClass")
class AnnotatedClass {}

public class AnnotationExample {
    public static void main(String[] args) {
        MyAnnotation ann = AnnotatedClass.class.getAnnotation(MyAnnotation.class);
        System.out.println("Annotation value: " + ann.value());
    }
}

