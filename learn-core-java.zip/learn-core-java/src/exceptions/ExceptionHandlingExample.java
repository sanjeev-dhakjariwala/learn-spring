package exceptions;

// Demonstrates try-catch-finally, multiple catch, custom exception
class MyCheckedException extends Exception {
    public MyCheckedException(String msg) { super(msg); }
}

public class ExceptionHandlingExample {
    public static void riskyMethod(boolean throwChecked) throws MyCheckedException {
        if (throwChecked) throw new MyCheckedException("Checked exception thrown");
        throw new RuntimeException("Unchecked exception thrown");
    }
    public static void main(String[] args) {
        try {
            riskyMethod(false);
        } catch (MyCheckedException e) {
            System.out.println("Caught checked: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Caught unchecked: " + e.getMessage());
        } finally {
            System.out.println("Finally block always runs");
        }
    }
}

