package io;

import java.io.*;

// Demonstrates file reading/writing
public class FileIOExample {
    public static void main(String[] args) throws IOException {
        String filename = "sample.txt";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("Hello, file!");
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            System.out.println("File content: " + reader.readLine());
        }
    }
}

