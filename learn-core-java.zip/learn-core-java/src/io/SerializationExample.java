package io;

import java.io.*;

// Demonstrates object serialization/deserialization
class Person implements Serializable {
    String name;
    Person(String name) { this.name = name; }
}

public class SerializationExample {
    public static void main(String[] args) throws Exception {
        String filename = "person.ser";
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
            out.writeObject(new Person("Alice"));
        }
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
            Person p = (Person) in.readObject();
            System.out.println("Deserialized: " + p.name);
        }
    }
}

