package com.sanjeev.learnspring.greeting.service;

public interface GreetingService {
    String greet(String name);
}

