package com.sanjeev.learnspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpingApplicationTests {

    @Test
    void contextLoads() {
    }

}
